# Copyright The OpenTelemetry Authors
# SPDX-License-Identifier: Apache-2.0


defmodule FeatureflagserviceWeb.PageViewTest do
  use FeatureflagserviceWeb.ConnCase, async: true
end
