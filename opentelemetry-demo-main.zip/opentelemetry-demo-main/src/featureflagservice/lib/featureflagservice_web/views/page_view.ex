# Copyright The OpenTelemetry Authors
# SPDX-License-Identifier: Apache-2.0


defmodule FeatureflagserviceWeb.PageView do
  use FeatureflagserviceWeb, :view
end
