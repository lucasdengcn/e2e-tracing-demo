# Copyright The OpenTelemetry Authors
# SPDX-License-Identifier: Apache-2.0


defmodule FeatureflagserviceWeb.FeatureFlagView do
  use FeatureflagserviceWeb, :view
end
