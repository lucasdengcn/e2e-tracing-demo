
rootProject.name = "frauddetectionservice"

