---
name: Question
about: Create a question to help us improve our knowledge base and documentation
labels: question
---

# Question

Use [Github Discussions](https://github.com/open-telemetry/opentelemetry-demo/discussions/).
